#!/usr/bin/env bash
set -e
roslaunch cartographer_ros backpack_3d.launch bag_filename:=/media/wenws/research_plus/space_for_linux/2_bagfile/correct_odom_village.bag
# roslaunch cartographer_ros backpack_3d.launch bag_filename:=/media/wenws/life/aroundpolyuwithcamera2017-09-18-15-13-56_filtered.bag
