/*
 * Copyright 2016 The Cartographer Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "cartographer_ros/node.h"

#include <chrono>
#include <string>
#include <vector>

#include "Eigen/Core"
#include "cartographer/common/make_unique.h"
#include "cartographer/common/port.h"
#include "cartographer/common/time.h"
#include "cartographer/mapping/proto/submap_visualization.pb.h"
#include "cartographer/mapping/sparse_pose_graph.h"
#include "cartographer/sensor/point_cloud.h"
#include "cartographer/transform/rigid_transform.h"
#include "cartographer/transform/transform.h"
#include "cartographer_ros/msg_conversion.h"
#include "cartographer_ros/sensor_bridge.h"
#include "cartographer_ros/tf_bridge.h"
#include "cartographer_ros/time_conversion.h"
#include "glog/logging.h"
#include "nav_msgs/Odometry.h"
#include "ros/serialization.h"
#include "sensor_msgs/PointCloud2.h"
#include "tf2_eigen/tf2_eigen.h"

namespace cartographer_ros {

namespace carto = ::cartographer;

using carto::transform::Rigid3d;

constexpr int kLatestOnlyPublisherQueueSize = 1;

Node::Node(const NodeOptions& options, tf2_ros::Buffer* const tf_buffer)
    : options_(options), map_builder_bridge_(options_, tf_buffer) {}

Node::~Node() {
  {
    carto::common::MutexLocker lock(&mutex_);
    terminating_ = true;
  }
  if (occupancy_grid_thread_.joinable()) {
    occupancy_grid_thread_.join();
  }
}

void Node::Initialize() {
  carto::common::MutexLocker lock(&mutex_);
  submap_list_publisher_ =
      node_handle_.advertise<::cartographer_ros_msgs::SubmapList>(
          kSubmapListTopic, kLatestOnlyPublisherQueueSize);
  submap_query_server_ = node_handle_.advertiseService(
      kSubmapQueryServiceName, &Node::HandleSubmapQuery, this);

  if (options_.map_builder_options.use_trajectory_builder_2d()) {
    occupancy_grid_publisher_ =
        node_handle_.advertise<::nav_msgs::OccupancyGrid>(
            kOccupancyGridTopic, kLatestOnlyPublisherQueueSize,
            true /* latched */);
    occupancy_grid_thread_ =
        std::thread(&Node::SpinOccupancyGridThreadForever, this);
  }

  scan_matched_point_cloud_publisher_ =
      node_handle_.advertise<sensor_msgs::PointCloud2>(
          kScanMatchedPointCloudTopic, kLatestOnlyPublisherQueueSize);

  wall_timers_.push_back(node_handle_.createWallTimer(
      ::ros::WallDuration(options_.submap_publish_period_sec),
      &Node::PublishSubmapList, this));
  wall_timers_.push_back(node_handle_.createWallTimer(
      ::ros::WallDuration(options_.pose_publish_period_sec),
      &Node::PublishTrajectoryStates, this));
  poseByCarto=node_handle_.advertise<geometry_msgs::Transform>("poseByCartographer",1000,this);
  poseByCarto_TransStamped=node_handle_.advertise<geometry_msgs::TransformStamped>("poseByCartoTranstamp",1000,this);//poseByCarto_TransStamped
  odometry_subscriber_1=node_handle_.subscribe("Odom_1",1000,&Node::callback_odom,this);
  odometry_EKF_subscriber_1=node_handle_.subscribe("poseByEKF",1000,&Node::callback_EKFodom,this);
  pub_Error=node_handle_.advertise<geometry_msgs::Point>("Error",1000,this);
  pub_odom_vo=node_handle_.advertise<nav_msgs::Odometry>("odom",1000,this);
  pub_imu_data=node_handle_.advertise<sensor_msgs::Imu>("imu_data",1000,this);//pub_imu_data
  imu_subscribe=node_handle_.subscribe("imu_rt",1000,&Node::callback_imu,this);


}

::ros::NodeHandle* Node::node_handle() { return &node_handle_; }

MapBuilderBridge* Node::map_builder_bridge() { return &map_builder_bridge_; }

bool Node::HandleSubmapQuery(
    ::cartographer_ros_msgs::SubmapQuery::Request& request,
    ::cartographer_ros_msgs::SubmapQuery::Response& response) {
  carto::common::MutexLocker lock(&mutex_);
  return map_builder_bridge_.HandleSubmapQuery(request, response);
}

void Node::PublishSubmapList(const ::ros::WallTimerEvent& unused_timer_event) {
  carto::common::MutexLocker lock(&mutex_);
  submap_list_publisher_.publish(map_builder_bridge_.GetSubmapList());
}

void Node::PublishTrajectoryStates(const ::ros::WallTimerEvent& timer_event) {
  carto::common::MutexLocker lock(&mutex_);
  for (const auto& entry : map_builder_bridge_.GetTrajectoryStates()) {
    const auto& trajectory_state = entry.second;

    geometry_msgs::TransformStamped stamped_transform;
    stamped_transform.header.stamp = ToRos(trajectory_state.pose_estimate.time);

    const auto& tracking_to_local = trajectory_state.pose_estimate.pose;
    const Rigid3d tracking_to_map =
        trajectory_state.local_to_map * tracking_to_local;

    // We only publish a point cloud if it has changed. It is not needed at high
    // frequency, and republishing it would be computationally wasteful.
    if (trajectory_state.pose_estimate.time !=
        last_scan_matched_point_cloud_time_) {
      scan_matched_point_cloud_publisher_.publish(ToPointCloud2Message(
          carto::common::ToUniversal(trajectory_state.pose_estimate.time),
          options_.tracking_frame,
          carto::sensor::TransformPointCloud(
              trajectory_state.pose_estimate.point_cloud,
              tracking_to_local.inverse().cast<float>())));
      last_scan_matched_point_cloud_time_ = trajectory_state.pose_estimate.time;
    } else {
      // If we do not publish a new point cloud, we still allow time of the
      // published poses to advance.
      stamped_transform.header.stamp = ros::Time::now();
    }

    if (trajectory_state.published_to_tracking != nullptr) {
      if (options_.provide_odom_frame) {
        std::vector<geometry_msgs::TransformStamped> stamped_transforms;

        stamped_transform.header.frame_id = options_.map_frame;
        // TODO(damonkohler): 'odom_frame' and 'published_frame' must be
        // per-trajectory to fully support the multi-robot use case.
        stamped_transform.child_frame_id = options_.odom_frame;
        stamped_transform.transform =
            ToGeometryMsgTransform(trajectory_state.local_to_map);
        stamped_transforms.push_back(stamped_transform);

        stamped_transform.header.frame_id = options_.odom_frame;
        stamped_transform.child_frame_id = options_.published_frame;
        stamped_transform.transform = ToGeometryMsgTransform(
            tracking_to_local * (*trajectory_state.published_to_tracking));
        stamped_transforms.push_back(stamped_transform);

        tf_broadcaster_.sendTransform(stamped_transforms);
	pose_temp_for_publish.translation.x=trajectory_state.pose_estimate.pose.translation().x();
	pose_temp_for_publish.translation.y=trajectory_state.pose_estimate.pose.translation().y();
	pose_temp_for_publish.translation.z=trajectory_state.pose_estimate.pose.translation().z();
	pose_temp_for_publish.rotation.x=trajectory_state.pose_estimate.pose.rotation().x();
	pose_temp_for_publish.rotation.y=trajectory_state.pose_estimate.pose.rotation().y();
	pose_temp_for_publish.rotation.z=trajectory_state.pose_estimate.pose.rotation().z();
	pose_temp_for_publish.rotation.w=trajectory_state.pose_estimate.pose.rotation().w();
	poseByCarto.publish(pose_temp_for_publish);//
	
	//publish poseStamped_temp_for_publish for error computing with time compensation
	poseStamped_temp_for_publish.transform=ToGeometryMsgTransform(tracking_to_map);
	poseStamped_temp_for_publish.header.frame_id="map";
	poseStamped_temp_for_publish.child_frame_id="odom";
	poseStamped_temp_for_publish.header.stamp=ToRos(trajectory_state.pose_estimate.time);
	poseByCarto_TransStamped.publish(poseStamped_temp_for_publish);
	
	geometry_msgs::Point error;
	error.x=0;
	//get error.x
	tf::Quaternion temp_quaternion_1;
	tf::quaternionMsgToTF(pose_temp_for_publish.rotation,temp_quaternion_1);
	tfScalar temp_1,temp_2,temp_3,temp_4;
	temp_1=odom_temp.pose.pose.orientation.x;
	temp_2=odom_temp.pose.pose.orientation.y;
	temp_3=odom_temp.pose.pose.orientation.z;
	temp_4=odom_temp.pose.pose.orientation.w;
	tf::Quaternion temp_quaternion_2(temp_1,temp_2,temp_3,temp_4);
	tfScalar pitch_1,roll_1,yaw_1;
	tfScalar pitch_2,roll_2,yaw_2;
	tfScalar pitch_3,roll_3,yaw_3;
	tf::Matrix3x3(temp_quaternion_1).getRPY(pitch_1,roll_1,yaw_1);
	tf::Matrix3x3(temp_quaternion_2).getRPY(pitch_2,roll_2,yaw_2);
	error.x=(yaw_1-yaw_2)*180/3.14159;
	//LOG(INFO) << "yaw_2=="<<yaw_2;
	if(error.x<-180) error.x=error.x+360;
	if(error.x>180) error.x=error.x-360;
	//get error.y
	error.y=(odom_temp.pose.pose.position.x-pose_temp_for_publish.translation.x)*
	(odom_temp.pose.pose.position.x-pose_temp_for_publish.translation.x);
	error.y=error.y+(odom_temp.pose.pose.position.y-pose_temp_for_publish.translation.y)*
	(odom_temp.pose.pose.position.y-pose_temp_for_publish.translation.y);
	error.y=sqrt(error.y);
	error.z=yaw_1*180/3.14159;
	//comparing the yaw error between odom_EKF and Odom_1
	
	//get error.z
	temp_1=odom_EKF.pose.pose.orientation.x;
	temp_2=odom_EKF.pose.pose.orientation.y;
	temp_3=odom_EKF.pose.pose.orientation.z;
	temp_4=odom_EKF.pose.pose.orientation.w;
	tf::Quaternion temp_quaternion_3(temp_1,temp_2,temp_3,temp_4);
	tf::Matrix3x3(temp_quaternion_3).getRPY(pitch_3,roll_3,yaw_3);
	error.x=yaw_3*180/3.14159;//yaw for EKF_odom
	//publish /vo topic
	pub_odom_vo.publish(odom_vo);
	//publish imu_data
	pub_imu_data.publish(Imu_temp);	
	pub_Error.publish(error);
	//print the time of trajectory pose time
      } else {
        stamped_transform.header.frame_id = options_.map_frame;
        stamped_transform.child_frame_id = options_.published_frame;
        stamped_transform.transform = ToGeometryMsgTransform(
            tracking_to_map * (*trajectory_state.published_to_tracking));
        tf_broadcaster_.sendTransform(stamped_transform);
      }
    }
  }
}
void Node::callback_odom(const nav_msgs::Odometry::ConstPtr& msg)
{
    odom_temp=*msg;
    odom_vo=*msg;
    odom_vo.header.frame_id="base_footprint";
    odom_vo.child_frame_id="";
    
    //odom_vo.pose.pose.orientation.x=Imu_temp.orientation.x+0.001;
    //odom_vo.pose.pose.orientation.y=Imu_temp.orientation.y+0.0001;
   // odom_vo.pose.pose.orientation.z=Imu_temp.orientation.z+0.0021;
   // odom_vo.pose.pose.orientation.w=Imu_temp.orientation.w+0.00020;
    
    odom_vo.pose.covariance[0]=1e-3;
    odom_vo.pose.covariance[7]=1e-3;
    odom_vo.pose.covariance[14]=1e6;
    odom_vo.pose.covariance[21]=1e6;
    odom_vo.pose.covariance[28]=1e6;
    odom_vo.pose.covariance[35]=1e3;

    odom_vo.pose.covariance[0]=1e-9;
    odom_vo.pose.covariance[7]=1e-3;
    odom_vo.pose.covariance[8]=1e-9;
    
    odom_vo.pose.covariance[14]=1e6;
    odom_vo.pose.covariance[21]=1e6;
    odom_vo.pose.covariance[28]=1e6;
    odom_vo.pose.covariance[35]=1e-9;
    //adjustment
    
}//
void Node::callback_EKFodom(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg)
{
    odom_EKF=*msg;
    
}//callback_EKFodom
void Node::callback_imu(const sensor_msgs::Imu::ConstPtr& msg)
{
    Imu_temp=*msg;
    Imu_temp.header.frame_id="base_footprint";
    Imu_temp.orientation_covariance[0]=1e6;
    Imu_temp.orientation_covariance[4]=1e6;
    Imu_temp.orientation_covariance[8]=1e-6;
    
    Imu_temp.angular_velocity_covariance[0]=1e6;
    Imu_temp.angular_velocity_covariance[4]=1e6;
    Imu_temp.angular_velocity_covariance[8]=1e-6;
    
    Imu_temp.linear_acceleration_covariance[0]=-1;
    
    
    
    
}

void Node::SpinOccupancyGridThreadForever() {
  for (;;) {
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    {
      carto::common::MutexLocker lock(&mutex_);
      if (terminating_) {
        return;
      }
    }
    if (occupancy_grid_publisher_.getNumSubscribers() == 0) {
      continue;
    }
    const auto occupancy_grid = map_builder_bridge_.BuildOccupancyGrid();
    if (occupancy_grid != nullptr) {
      occupancy_grid_publisher_.publish(*occupancy_grid);
    }
  }
}

}  // namespace cartographer_ros
